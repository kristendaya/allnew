import random

class BinaryConverter:
    def __init__(self, x):
        self.x = x

    def convertbinary(self):
        temp = []
        while True:
            remain = self.x % 2
            self.x = self.x // 2
            temp.append(remain)

            if self.x < 2:
                temp.append(self.x)
                break
        temp.reverse()
        return temp

            ##return 은 무조건 함수밖에 없다.
x=random.randint(4,16)
n=BinaryConverter(x)
print(f'{x}={n.convertbinary()}')